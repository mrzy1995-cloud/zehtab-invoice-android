package ir.zehtab.invoice;

import android.app.Activity;
import android.content.ContentValues;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import java.io.OutputStream;

public class MainActivity extends Activity {
  private WebView webView;

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    webView = new WebView(this);
    setContentView(webView);
    WebSettings settings = webView.getSettings();
    settings.setJavaScriptEnabled(true);
    settings.setDomStorageEnabled(true);
    settings.setAllowFileAccess(true);
    settings.setAllowContentAccess(false);
    settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    webView.setWebChromeClient(new WebChromeClient());
    webView.addJavascriptInterface(new AndroidBridge(), "Android");
    webView.loadUrl("file:///android_asset/invoice.html");
  }

  @Override public void onBackPressed() {
    if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
  }

  final class AndroidBridge {
    @JavascriptInterface public void saveImage(String dataUrl, String fileName) {
      try {
        byte[] bytes = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
        values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
        values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Zehtab Invoices");
        android.net.Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new Exception("Cannot create image");
        try (OutputStream out = getContentResolver().openOutputStream(uri)) { out.write(bytes); }
        runOnUiThread(() -> Toast.makeText(MainActivity.this,
            "فاکتور در پوشه تصاویر ذخیره شد", Toast.LENGTH_LONG).show());
      } catch (Exception error) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this,
            "ذخیره تصویر انجام نشد", Toast.LENGTH_LONG).show());
      }
    }
  }
}
