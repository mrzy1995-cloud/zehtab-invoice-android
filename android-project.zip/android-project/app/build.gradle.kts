plugins { id("com.android.application") }

android {
    namespace = "ir.zehtab.invoice"
    compileSdk = 35
    defaultConfig {
        applicationId = "ir.zehtab.invoice"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
